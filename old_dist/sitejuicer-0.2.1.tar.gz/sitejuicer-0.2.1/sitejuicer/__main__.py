"""
Main entry point for the sitejuicer package when executed as a module.
"""

from sitejuicer.cli import main

if __name__ == "__main__":
    main() 