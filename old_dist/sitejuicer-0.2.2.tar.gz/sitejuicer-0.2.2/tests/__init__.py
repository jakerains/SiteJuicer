"""
Test package for SiteJuicer
""" 